//
//  ViewController.h
//  PageScrollView-Demo
//
//  Created by XuQingQing on 15-1-25.
//  Copyright (c) 2015年 XQQ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MSTabScrollView.h"

@interface ViewController : UIViewController<MSTabScrollViewDelegate>


@end

