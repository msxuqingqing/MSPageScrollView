//
//  AppDelegate.h
//  PageScrollView-Demo
//
//  Created by XuQingQing on 15-1-25.
//  Copyright (c) 2015年 XQQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

